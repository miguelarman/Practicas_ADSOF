package adsof1718.grafos.got;

public class PersonajeGOT {
	
	private String nombre;
	private String casa;

	public PersonajeGOT(String nombre, String casa) {
		this.nombre = nombre;
		this.casa = casa;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public String getCasa() {
		return this.casa;
	}
	
}
